import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Terminal as TerminalIcon, Sparkles, ShieldAlert, Cpu, Layers, Bell, Zap, X, Trash2, Smartphone, HelpCircle, Gamepad2, Heart, ShieldCheck, Check, Loader2, Coins } from 'lucide-react';
import Dashboard from './components/Dashboard';
import SettingsList from './components/SettingsList';
import BuyKeyList from './components/BuyKeyList';
import { TerminalLog, SystemMetrics } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'buykey' | 'settings'>('dashboard');
  
  // Human verification states
  const [isVerifiedHuman, setIsVerifiedHuman] = useState<boolean>(false);
  const [isVerifyingHuman, setIsVerifyingHuman] = useState(false);
  const [verificationSuccess, setVerificationSuccess] = useState(false);
  const [verifyStep, setVerifyStep] = useState(0);

  const [logs, setLogs] = useState<TerminalLog[]>([
    { id: '1', timestamp: '18:30:12', type: 'system', message: 'Hệ thống Hack Kazu v4.0 khởi tạo hoàn tất.' },
    { id: '2', timestamp: '18:30:13', type: 'success', message: 'Liên kết thành công máy chủ Delta VNG Cloud.' },
    { id: '3', timestamp: '18:30:15', type: 'warning', message: 'Phát hiện thiết bị chưa cài đặt chứng chỉ iOS Fix Lag.' }
  ]);
  const [metrics, setMetrics] = useState<SystemMetrics>({
    ping: 28,
    fps: 60,
    ramUsage: 45,
    bypassRate: 99.8,
    activeUsers: 8492
  });
  
  const [notifications, setNotifications] = useState<{ id: string; message: string; type: 'success' | 'info' }[]>([]);
  const logsContainerRef = useRef<HTMLDivElement>(null);

  // Auto-scroll logs to bottom within its container only, without scrolling the main window
  useEffect(() => {
    if (logsContainerRef.current) {
      logsContainerRef.current.scrollTop = logsContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Fluctuating real-time metrics simulator for gaming app feel
  useEffect(() => {
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        ping: Math.max(12, Math.min(120, prev.ping + Math.floor(Math.random() * 7) - 3)),
        fps: Math.max(55, Math.min(120, prev.fps + Math.floor(Math.random() * 3) - 1)),
        ramUsage: Math.max(38, Math.min(82, prev.ramUsage + parseFloat((Math.random() * 2 - 1).toFixed(1))))
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const addLog = (message: string, type: 'system' | 'success' | 'warning' | 'error') => {
    const time = new Date();
    const timestamp = `${time.getHours().toString().padStart(2, '0')}:${time.getMinutes().toString().padStart(2, '0')}:${time.getSeconds().toString().padStart(2, '0')}`;
    const id = `${Date.now()}-${Math.floor(Math.random() * 10000000)}`;
    setLogs(prev => [
      ...prev,
      { id, timestamp, type, message }
    ]);
  };

  const clearLogs = () => {
    setLogs([]);
    addLog('Đã dọn dẹp toàn bộ dữ liệu log bộ nhớ tạm.', 'system');
  };

  const triggerNotification = (message: string, type: 'success' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.floor(Math.random() * 10000000)}`;
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  const handleHumanVerify = () => {
    if (isVerifyingHuman || verificationSuccess) return;
    setIsVerifyingHuman(true);
    setVerifyStep(1);
    
    // Simulate multi-stage Cloudflare-like challenge verification
    setTimeout(() => {
      setVerifyStep(2);
    }, 800);
    
    setTimeout(() => {
      setVerifyStep(3);
    }, 1600);
    
    setTimeout(() => {
      setVerifyStep(4);
      setVerificationSuccess(true);
      triggerNotification('Xác minh thành công! Chào mừng đến với Kazu Hack.', 'success');
    }, 2400);

    setTimeout(() => {
      setIsVerifiedHuman(true);
      addLog('Đã hoàn thành xác minh con người thành công qua Kazu Gateway.', 'success');
    }, 3200);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans relative overflow-x-hidden cyber-grid">
      {/* Human Verification Fullscreen Gate */}
      <AnimatePresence>
        {!isVerifiedHuman && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-4 overflow-y-auto select-none cyber-grid"
          >
            {/* Glowing background shapes */}
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ delay: 0.1, duration: 0.3 }}
              className="max-w-md w-full bg-slate-900/90 border border-emerald-500/20 rounded-3xl p-6 md:p-8 text-center backdrop-blur-xl relative shadow-2xl shadow-emerald-500/5 space-y-6"
            >
              {/* Top gradient border bar */}
              <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 rounded-t-3xl" />

              {/* Logo / Title */}
              <div className="flex flex-col items-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-400 p-[1px] shadow-lg shadow-emerald-500/20 flex items-center justify-center">
                  <div className="w-full h-full bg-slate-950 rounded-[15px] flex items-center justify-center text-emerald-400">
                    <ShieldCheck size={28} className={isVerifyingHuman ? "animate-pulse" : ""} />
                  </div>
                </div>
                <span className="text-lg font-black tracking-wider bg-gradient-to-r from-emerald-400 to-cyan-300 bg-clip-text text-transparent uppercase font-mono">
                  HỆ THỐNG XÁC MINH AN TOÀN
                </span>
                <p className="text-xs text-slate-400">Yêu cầu hoàn thành thử thách bảo mật để truy cập Kazu Hack v4.0</p>
              </div>

              {/* Simulation logs/status info */}
              <div className="bg-slate-950/75 border border-slate-800/80 p-4 rounded-2xl text-left space-y-2.5 font-mono text-[11px] leading-relaxed">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-900 text-slate-400">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  <span>Trạng thái kiểm tra trình duyệt:</span>
                </div>
                {verifyStep === 0 && (
                  <div className="text-slate-400">🔒 Đang chờ kích hoạt xác minh...</div>
                )}
                {verifyStep >= 1 && (
                  <div className="text-cyan-400 flex items-center gap-1.5">
                    <Loader2 size={12} className="animate-spin" />
                    <span>[Step 1] Đang kết nối máy chủ phân tích IP...</span>
                  </div>
                )}
                {verifyStep >= 2 && (
                  <div className="text-cyan-400 flex items-center gap-1.5">
                    <Loader2 size={12} className="animate-spin" />
                    <span>[Step 2] Kiểm tra chứng chỉ chữ ký số Delta...</span>
                  </div>
                )}
                {verifyStep >= 3 && (
                  <div className="text-teal-400 flex items-center gap-1.5">
                    <Loader2 size={12} className="animate-spin" />
                    <span>[Step 3] Xác thực vân tay trình duyệt không robot...</span>
                  </div>
                )}
                {verifyStep >= 4 && (
                  <div className="text-emerald-400 font-bold flex items-center gap-1.5">
                    <Check size={12} className="text-emerald-400" />
                    <span>[Thành Công] Khởi tạo môi trường Hack Kazu...</span>
                  </div>
                )}
              </div>

              {/* Main Interaction checkbox */}
              <button
                onClick={handleHumanVerify}
                disabled={isVerifyingHuman || verificationSuccess}
                className={`w-full p-4 rounded-2xl border text-left flex items-center justify-between transition-all select-none group relative ${
                  verificationSuccess
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                    : isVerifyingHuman
                      ? 'bg-slate-950/60 border-slate-800 text-cyan-400'
                      : 'bg-slate-950 hover:bg-slate-950/80 border-slate-800 hover:border-emerald-500/30 text-slate-200 cursor-pointer'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Styled Checkbox box */}
                  <div className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
                    verificationSuccess
                      ? 'bg-emerald-500 border-emerald-500 text-slate-950'
                      : isVerifyingHuman
                        ? 'border-cyan-500/40'
                        : 'border-slate-700 group-hover:border-emerald-500/40 bg-slate-900'
                  }`}>
                    {verificationSuccess ? (
                      <Check size={14} strokeWidth={3} />
                    ) : isVerifyingHuman ? (
                      <Loader2 size={12} className="animate-spin text-cyan-400" />
                    ) : null}
                  </div>
                  <span className="text-xs font-bold font-sans tracking-wide">
                    {verificationSuccess 
                      ? 'XÁC MINH HOÀN TẤT!' 
                      : isVerifyingHuman 
                        ? 'Vui lòng giữ kết nối...' 
                        : 'Tôi không phải là người máy (Tôi là con người)'}
                  </span>
                </div>

                {/* Cloudflare-like side badge */}
                <div className="flex flex-col items-end opacity-40 group-hover:opacity-75 transition-opacity text-[8px] font-mono leading-tight">
                  <span className="font-extrabold uppercase text-emerald-400 tracking-wider">Kazu Gate</span>
                  <span>Bảo mật tự động</span>
                </div>
              </button>

              {/* Security guarantee footer */}
              <div className="pt-2 border-t border-slate-800/60 flex items-center justify-center gap-1.5 text-[9px] text-slate-500 font-mono">
                <ShieldCheck size={11} className="text-emerald-500" />
                <span>Được mã hóa hoàn toàn bởi chuẩn bảo mật SSL v3</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background glowing effects */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px] -z-10 pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[120px] -z-10 pointer-events-none" />

      {/* Header Bar */}
      <header className="border-b border-emerald-500/10 bg-slate-900/40 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-500 p-[1px] shadow-lg shadow-emerald-500/10">
              <div className="w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center">
                <Gamepad2 size={20} className="text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-extrabold tracking-tight bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent uppercase font-mono">
                  HACK KAZU
                </span>
                <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 text-[9px] font-bold tracking-widest border border-emerald-500/20 uppercase">
                  V4.0
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-medium">Bản Quyền Delta VNG Android & iOS</p>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="flex items-center gap-1.5">
            {[
              { id: 'dashboard', label: 'TRANG CHỦ', icon: Cpu },
              { id: 'buykey', label: 'MUA KEY VIP', icon: Coins },
              { id: 'settings', label: 'TẢI GAME & LIÊN HỆ', icon: Smartphone }
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  id={`nav-${tab.id}`}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`px-3 py-1.5 md:px-4 md:py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                      : 'hover:bg-slate-900/60 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon size={14} />
                  <span className="hidden sm:inline">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 py-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Multi-tab content view */}
        <div className="lg:col-span-2 space-y-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard
                  metrics={metrics}
                  triggerNotification={triggerNotification}
                  addLog={addLog}
                />
              )}
              {activeTab === 'buykey' && (
                <BuyKeyList
                  triggerNotification={triggerNotification}
                  addLog={addLog}
                />
              )}
              {activeTab === 'settings' && (
                <SettingsList
                  triggerNotification={triggerNotification}
                  addLog={addLog}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Right Column: Interactive Log Terminal */}
        <div className="space-y-6">
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden flex flex-col h-[340px] shadow-xl backdrop-blur-md">
            {/* Terminal Top bar */}
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TerminalIcon size={14} className="text-emerald-400" />
                <span className="text-xs font-extrabold text-slate-200 font-mono tracking-wider">
                  TERMINAL SYSTEM LOGS
                </span>
              </div>
              <button
                onClick={clearLogs}
                title="Dọn dẹp logs"
                className="p-1 hover:bg-slate-900 rounded text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
              >
                <Trash2 size={13} />
              </button>
            </div>

            {/* Terminal log output stream */}
            <div 
              ref={logsContainerRef}
              className="flex-1 overflow-y-auto p-4 space-y-2.5 font-mono text-[11px] leading-relaxed select-text bg-slate-950/40 scroll-smooth"
            >
              {logs.map((log) => {
                let colorClass = 'text-slate-400';
                if (log.type === 'success') colorClass = 'text-emerald-400';
                if (log.type === 'warning') colorClass = 'text-amber-400';
                if (log.type === 'error') colorClass = 'text-rose-400 animate-pulse';

                return (
                  <div key={log.id} className="flex items-start gap-2">
                    <span className="text-slate-600 shrink-0 select-none">[{log.timestamp}]</span>
                    <span className={`${colorClass} break-all`}>
                      {log.type === 'system' ? '⚙️' : ''} {log.message}
                    </span>
                  </div>
                );
              })}
              {logs.length === 0 && (
                <div className="text-slate-600 text-center py-12">Không có log ghi lại.</div>
              )}
            </div>

            <div className="bg-slate-950/80 px-4 py-2 border-t border-slate-900 text-[10px] text-slate-500 flex justify-between items-center font-mono">
              <span>Auto-Bypass: ONLINE</span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                VNG Gateway: Live
              </span>
            </div>
          </div>

          {/* Quick Support / About Banner */}
          <div className="bg-gradient-to-tr from-emerald-500/10 to-cyan-500/10 border border-emerald-500/10 p-5 rounded-2xl space-y-4">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="text-emerald-400" size={13} />
              Cấu Hình Khuyên Dùng
            </h3>
            <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
              Đối với thiết bị iOS / Android cấu hình yếu, khuyến cáo kích hoạt tính năng <strong className="text-emerald-400">Super Fix Lag</strong> kết hợp giảm chất lượng họa tiết đồ họa trong Roblox xuống 1 vạch để tận hưởng trải nghiệm mượt mà không văng game.
            </p>
            <div className="pt-1 flex flex-wrap gap-2">
              <span className="px-2 py-0.5 bg-slate-900/80 rounded text-[9px] font-medium text-slate-400 border border-slate-800">
                Ram khuyên dùng: 4GB+
              </span>
              <span className="px-2 py-0.5 bg-slate-900/80 rounded text-[9px] font-medium text-slate-400 border border-slate-800">
                Roblox VNG Client
              </span>
            </div>
          </div>
        </div>
      </main>

      {/* Floating Notifications */}
      <div className="fixed bottom-4 right-4 z-50 space-y-2 pointer-events-none">
        <AnimatePresence>
          {notifications.map((notif) => (
            <motion.div
              key={notif.id}
              initial={{ opacity: 0, x: 50, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 50, scale: 0.9 }}
              className="bg-slate-900/95 border border-emerald-500/30 text-slate-100 p-4 rounded-xl shadow-2xl flex items-center gap-3 max-w-sm pointer-events-auto"
            >
              <div className="p-1.5 bg-emerald-500/10 rounded-lg text-emerald-400 shrink-0">
                <Bell size={14} className="animate-bounce" />
              </div>
              <span className="text-xs font-bold leading-normal">{notif.message}</span>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
