import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CreditCard, CheckCircle, ShieldCheck, Copy, Check, ExternalLink, MessageCircle, AlertCircle, Sparkles, Coins, HelpCircle } from 'lucide-react';

interface BuyKeyListProps {
  triggerNotification: (msg: string, type: 'success' | 'info') => void;
  addLog: (msg: string, type: 'system' | 'success' | 'warning' | 'error') => void;
}

interface KeyPackage {
  id: string;
  code: string;
  duration: string;
  price: number;
  priceRaw: number;
  desc: string;
  badge?: string;
  isPopular?: boolean;
}

export default function BuyKeyList({ triggerNotification, addLog }: BuyKeyListProps) {
  const [username, setUsername] = useState('');
  const [selectedPackage, setSelectedPackage] = useState<KeyPackage>({
    id: '3d',
    code: '3D',
    duration: '3 Ngày',
    price: 15000,
    priceRaw: 15000,
    desc: 'Trải nghiệm mượt mà, không quảng cáo, bypass key tốc độ cao.',
  });
  const [copiedText, setCopiedText] = useState<string | null>(null);
  const [transactionId, setTransactionId] = useState('');

  // Generate a random 4-digit ID for payment verification on mount or package switch
  useEffect(() => {
    setTransactionId(Math.floor(1000 + Math.random() * 9000).toString());
  }, [selectedPackage.id]);

  const packages: KeyPackage[] = [
    {
      id: '3d',
      code: '3D',
      duration: '3 Ngày',
      price: 15000,
      priceRaw: 15000,
      desc: 'Phù hợp thử nghiệm tính năng VIP, giá siêu sinh viên.',
    },
    {
      id: '5d',
      code: '5D',
      duration: '5 Ngày',
      price: 20000,
      priceRaw: 20000,
      desc: 'Thêm thời hạn, cày cuốc thoải mái suốt tuần học tập.',
    },
    {
      id: '10d',
      code: '10D',
      duration: '10 Ngày',
      price: 35000,
      priceRaw: 35000,
      desc: 'Gói bán chạy! Tiết kiệm hơn, trải nghiệm không gián đoạn.',
      isPopular: true,
    },
    {
      id: '1m',
      code: '1M',
      duration: '1 Tháng',
      price: 60000,
      priceRaw: 60000,
      desc: 'Quên đi nỗi lo lấy key hàng ngày, cày game thả ga 30 ngày.',
      badge: 'Khuyên Dùng',
    },
    {
      id: '3m',
      code: '3M',
      duration: '3 Tháng',
      price: 90000,
      priceRaw: 90000,
      desc: 'Siêu tiết kiệm cho game thủ đích thực. Ưu tiên cập nhật bản mới.',
    },
    {
      id: 'vv',
      code: 'VV',
      duration: 'Vĩnh Viễn',
      price: 150000,
      priceRaw: 150000,
      desc: 'Đẳng cấp tuyệt đối! Sở hữu trọn đời mọi đặc quyền Hack Kazu VIP.',
      badge: 'Đặc Quyền VIP',
    },
  ];

  const formatPrice = (value: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
  };

  const getCleanUsername = () => {
    if (!username.trim()) return 'CLIENT';
    // Remove vietnamese accents and spaces for standard bank transfer content
    return username
      .trim()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .replace(/[^a-zA-Z0-9]/g, '_')
      .toUpperCase();
  };

  const transferContent = `KAZU ${getCleanUsername()} ${selectedPackage.code} ${transactionId}`;

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    triggerNotification(`Đã sao chép ${label}!`, 'success');
    addLog(`Đã sao chép ${label}: ${text}`, 'success');
    setTimeout(() => setCopiedText(null), 2000);
  };

  const qrCodeUrl = `https://img.vietqr.io/image/vietinbank-103868422231-compact2.png?amount=${selectedPackage.priceRaw}&addInfo=${encodeURIComponent(transferContent)}&accountName=NGUYEN%20THI%20CHI`;

  return (
    <div className="space-y-6">
      {/* Title block */}
      <div className="bg-slate-900/60 border border-emerald-500/10 rounded-2xl p-6 relative overflow-hidden backdrop-blur-md">
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl -z-10" />
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-emerald-500/10 rounded-lg text-emerald-400">
            <Coins size={20} />
          </div>
          <div>
            <h1 className="text-base font-extrabold text-slate-100 tracking-tight flex items-center gap-2">
              Mua Key VIP Premium Kazu Hack
              <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[9px] font-bold rounded border border-emerald-500/20 uppercase">
                Tự Động 24/7
              </span>
            </h1>
            <p className="text-xs text-slate-400">Mua Key hỗ trợ nhà phát triển, mở khóa toàn bộ đặc quyền VIP, không quảng cáo, bypass key mượt mà.</p>
          </div>
        </div>
      </div>

      {/* Grid of packages & Payment method */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left Column: List of Packages */}
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
              <Sparkles size={13} className="text-emerald-400" />
              Bước 1: Chọn gói thời gian của bạn
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {packages.map((pkg) => {
              const isSelected = selectedPackage.id === pkg.id;
              return (
                <motion.div
                  key={pkg.id}
                  onClick={() => setSelectedPackage(pkg)}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  className={`p-4 rounded-xl border text-left cursor-pointer transition-all flex flex-col justify-between relative overflow-hidden h-full ${
                    isSelected
                      ? 'bg-emerald-500/10 border-emerald-500/50 shadow-md shadow-emerald-500/5'
                      : 'bg-slate-900/40 hover:bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {pkg.badge && (
                    <div className="absolute top-0 right-0 px-2 py-0.5 bg-emerald-500 text-slate-950 font-mono text-[8px] font-bold rounded-bl-lg uppercase tracking-wider">
                      {pkg.badge}
                    </div>
                  )}
                  {pkg.isPopular && !pkg.badge && (
                    <div className="absolute top-0 right-0 px-2 py-0.5 bg-cyan-500 text-slate-950 font-mono text-[8px] font-bold rounded-bl-lg uppercase tracking-wider">
                      Bán Chạy
                    </div>
                  )}

                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <span className={`text-xs font-extrabold tracking-wider font-mono uppercase ${
                        isSelected ? 'text-emerald-400' : 'text-slate-300'
                      }`}>
                        GÓI {pkg.duration}
                      </span>
                      {isSelected && (
                        <CheckCircle size={12} className="text-emerald-400" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-normal line-clamp-2 pr-10">{pkg.desc}</p>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-baseline justify-between">
                    <span className="text-[10px] text-slate-500 font-medium">Giá thanh toán:</span>
                    <span className="text-sm font-extrabold text-emerald-400 font-mono">{formatPrice(pkg.price)}</span>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* User inputs for dynamic content */}
          <div className="bg-slate-900/40 border border-slate-800/80 p-5 rounded-2xl space-y-4">
            <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
              Tùy chọn: Nhập Tên của bạn (Để tạo nội dung CK nhanh)
            </h3>
            <div className="space-y-1">
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Ví dụ: KazuPro, NguyenVanA..."
                maxLength={15}
                className="w-full bg-slate-950/80 border border-slate-800/80 focus:border-emerald-500/50 rounded-xl px-4 py-3 font-mono text-xs text-slate-200 outline-none placeholder:text-slate-600 transition-colors"
              />
              <p className="text-[10px] text-slate-500 italic">
                *Hệ thống sẽ tự động chuyển đổi sang chữ viết hoa không dấu để ngân hàng ghi nhận nhanh nhất.
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic VietQR Payment details */}
        <div className="lg:col-span-2 space-y-4">
          <h2 className="text-xs font-bold text-slate-300 uppercase tracking-widest flex items-center gap-2">
            <CreditCard size={13} className="text-emerald-400" />
            Bước 2: Quét mã QR hoặc Chuyển Khoản
          </h2>

          <div className="bg-slate-900/60 border border-emerald-500/15 rounded-2xl p-5 backdrop-blur-md space-y-5 relative">
            {/* VietQR design */}
            <div className="flex flex-col items-center">
              {/* Premium QR Wrapper */}
              <div className="bg-white p-3.5 rounded-2xl shadow-xl shadow-slate-950/40 relative group max-w-[200px] w-full">
                <img
                  src={qrCodeUrl}
                  alt="VietQR VietinBank Nguyen Thi Chi"
                  className="w-full h-auto object-contain rounded-lg"
                  referrerPolicy="no-referrer"
                />
                
                {/* Micro Scan Helper Banner */}
                <div className="absolute inset-x-3 -bottom-2 bg-slate-950 text-[8px] font-bold text-emerald-400 py-1 px-2 rounded-md border border-emerald-500/20 shadow flex items-center justify-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping shrink-0" />
                  <span>MÃ QR TỰ ĐỘNG KHỚP GIÁ</span>
                </div>
              </div>

              {/* QR Scan Instructions */}
              <span className="text-[10px] text-slate-500 font-mono mt-4 text-center">
                Mở App Ngân hàng bất kỳ để quét nhanh không cần nhập tay
              </span>
            </div>

            {/* Manual bank details copy */}
            <div className="space-y-3.5 border-t border-slate-800/80 pt-4">
              <div className="flex items-center gap-2 pb-1 text-slate-400 text-xs font-bold font-mono">
                <ShieldCheck size={14} className="text-emerald-400" />
                <span>THÔNG TIN CHUYỂN KHOẢN THỦ CÔNG</span>
              </div>

              <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-900 space-y-2.5 font-mono text-[11px]">
                {/* Bank Name */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Ngân hàng:</span>
                  <span className="text-slate-300 font-extrabold text-right">VietinBank (Công Thương)</span>
                </div>

                {/* Account Name */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Chủ tài khoản:</span>
                  <span className="text-slate-300 font-extrabold text-right">NGUYEN THI CHI</span>
                </div>

                {/* Account Number */}
                <div className="flex items-center justify-between border-t border-slate-900/60 pt-2">
                  <span className="text-slate-500">Số tài khoản:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-extrabold">103868422231</span>
                    <button
                      onClick={() => handleCopy('103868422231', 'Số tài khoản')}
                      className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                    >
                      {copiedText === '103868422231' ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>

                {/* Transfer Amount */}
                <div className="flex items-center justify-between border-t border-slate-900/60 pt-2">
                  <span className="text-slate-500">Số tiền CK:</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-emerald-400 font-extrabold">{formatPrice(selectedPackage.price)}</span>
                    <button
                      onClick={() => handleCopy(selectedPackage.priceRaw.toString(), 'Số tiền')}
                      className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                    >
                      {copiedText === selectedPackage.priceRaw.toString() ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>

                {/* Transfer Content */}
                <div className="flex flex-col gap-1 border-t border-slate-900/60 pt-2">
                  <span className="text-slate-500">Nội dung CK (Ghi chú bắt buộc):</span>
                  <div className="bg-slate-900 px-3 py-2 rounded-lg border border-slate-800 flex items-center justify-between gap-2 mt-1">
                    <span className="text-emerald-300 font-extrabold font-mono text-xs tracking-wider select-all">
                      {transferContent}
                    </span>
                    <button
                      onClick={() => handleCopy(transferContent, 'Nội dung chuyển khoản')}
                      className="p-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-md transition-colors cursor-pointer shrink-0"
                    >
                      {copiedText === transferContent ? <Check size={12} className="text-emerald-400" strokeWidth={3} /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Bill via Zalo instruction */}
            <div className="bg-slate-950/40 border border-amber-500/20 rounded-xl p-4 space-y-3.5">
              <div className="flex items-start gap-2.5">
                <AlertCircle size={15} className="text-amber-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h4 className="text-[11px] font-bold text-amber-300 uppercase font-sans">
                    LƯU Ý QUAN TRỌNG: GỬI BILL ĐỂ NHẬN KEY
                  </h4>
                  <p className="text-[10px] text-slate-400 leading-normal font-sans">
                    Sau khi thực hiện giao dịch chuyển khoản thành công, hãy nhấn nút dưới đây để gửi trực tiếp hình ảnh biên lai (Bill) cho Admin qua Zalo để nhận mã Key VIP Premium ngay lập tức.
                  </p>
                </div>
              </div>

              <a
                href="https://zalo.me/0947691156"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => addLog('Đang chuyển tới Zalo admin 0947691156 để gửi bill...', 'system')}
                className="w-full py-3 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-md shadow-emerald-500/10 transition-all cursor-pointer text-center"
              >
                <MessageCircle size={14} fill="currentColor" />
                <span>GỬI BILL CHO ADMIN QUA ZALO (0947691156)</span>
                <ExternalLink size={12} />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
