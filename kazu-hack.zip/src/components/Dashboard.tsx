import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Shield, Cpu, RefreshCw, Zap, Wifi, Users, CheckCircle, Smartphone, Download, Settings, HelpCircle, Info, ShieldAlert } from 'lucide-react';
import { SystemMetrics } from '../types';

interface DashboardProps {
  metrics: SystemMetrics;
  triggerNotification: (msg: string, type: 'success' | 'info') => void;
  addLog: (msg: string, type: 'system' | 'success' | 'warning' | 'error') => void;
}

export default function Dashboard({ metrics, triggerNotification, addLog }: DashboardProps) {
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [optimizationProgress, setOptimizationProgress] = useState(0);
  const [currentStepText, setCurrentStepText] = useState('');
  const [selectedOS, setSelectedOS] = useState<'ios' | 'android'>('ios');
  
  // Real-time fluctuating users count
  const [activeUsers, setActiveUsers] = useState(metrics.activeUsers);
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveUsers(prev => prev + Math.floor(Math.random() * 9) - 4);
    }, 4000);
    return () => clearInterval(interval);
  }, [metrics.activeUsers]);

  const handleOptimize = () => {
    if (isOptimizing) return;
    setIsOptimizing(true);
    setOptimizationProgress(0);
    addLog('Đang khởi chạy hệ thống dọn dẹp Delta Fix Lag...', 'system');
    
    const steps = [
      'Đang giải phóng bộ nhớ RAM đệm...',
      'Đang dọn dẹp cache game Roblox VNG...',
      'Đang vô hiệu hóa tiến trình chạy ngầm gây giật lag...',
      'Đang tối ưu hóa kết nối DNS Kazu Safe Net...',
      'Đã hoàn tất cấu hình Siêu Fix Lag!'
    ];

    let currentStep = 0;
    setCurrentStepText(steps[0]);

    let progress = 0;
    const timer = setInterval(() => {
      progress += 4;
      if (progress >= 100) {
        clearInterval(timer);
        setOptimizationProgress(100);
        setIsOptimizing(false);
        triggerNotification('Thiết bị của bạn đã được tối ưu hóa siêu mượt!', 'success');
        addLog('Hệ thống dọn dẹp RAM & Fix Lag đã thực thi thành công!', 'success');
      } else {
        setOptimizationProgress(progress);
        const stepIndex = Math.floor((progress / 100) * steps.length);
        if (stepIndex < steps.length && stepIndex !== currentStep) {
          currentStep = stepIndex;
          setCurrentStepText(steps[stepIndex] || 'Đang xử lý...');
        }
      }
    }, 100);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    triggerNotification(`Đã sao chép ${label}!`, 'success');
  };

  return (
    <div className="space-y-6">
      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Bypass Anticheat', value: 'An Toàn (99.8%)', desc: 'Trạng thái hoạt động', icon: Shield, color: 'text-emerald-400 border-emerald-500/20 bg-emerald-500/5' },
          { label: 'Độ Trễ (Ping)', value: `${metrics.ping} ms`, desc: 'Tốc độ kết nối', icon: Wifi, color: 'text-cyan-400 border-cyan-500/20 bg-cyan-500/5' },
          { label: 'Tốc độ khung hình', value: `${metrics.fps} FPS`, desc: 'Bẻ khóa giới hạn 120Hz', icon: Cpu, color: 'text-purple-400 border-purple-500/20 bg-purple-500/5' },
          { label: 'Người dùng trực tuyến', value: activeUsers.toLocaleString(), desc: 'Đang dùng Hack Kazu', icon: Users, color: 'text-amber-400 border-amber-500/20 bg-amber-500/5' },
        ].map((item, index) => (
          <motion.div
            key={item.label}
            id={`metric-card-${index}`}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className={`p-4 rounded-xl border ${item.color} flex flex-col justify-between`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">{item.label}</span>
              <item.icon size={16} />
            </div>
            <div>
              <span className="text-lg md:text-xl font-bold font-mono block tracking-tight">{item.value}</span>
              <span className="text-[10px] text-slate-500">{item.desc}</span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6">
        {/* Anti Lag Booster Section */}
        <motion.div
          id="booster-section"
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-slate-900/60 border border-emerald-500/10 rounded-2xl p-6 relative overflow-hidden backdrop-blur-md"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl -z-10" />
          
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2 mb-2">
            <Zap className="text-emerald-400" size={18} />
            Kazu Super Fix Lag v4.0
          </h2>
          <p className="text-xs text-slate-400 mb-6">
            Dọn dẹp RAM tối đa, giải phóng dung lượng rác và tối ưu băng thông kết nối cho Delta Executor trên điện thoại của bạn.
          </p>

          <div className="flex flex-col items-center justify-center py-6">
            {/* Spinning/pulsing action circle */}
            <div className="relative w-36 h-36 flex items-center justify-center">
              <svg className="absolute inset-0 w-full h-full transform -rotate-95">
                <circle
                  cx="72"
                  cy="72"
                  r="62"
                  className="stroke-slate-800"
                  strokeWidth="6"
                  fill="transparent"
                />
                <motion.circle
                  cx="72"
                  cy="72"
                  r="62"
                  className="stroke-emerald-400"
                  strokeWidth="8"
                  fill="transparent"
                  strokeDasharray={2 * Math.PI * 62}
                  strokeDashoffset={2 * Math.PI * 62 * (1 - (isOptimizing ? optimizationProgress : 100) / 100)}
                  transition={{ ease: 'easeOut' }}
                />
              </svg>
              
              <motion.button
                id="optimize-btn"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleOptimize}
                disabled={isOptimizing}
                className={`w-28 h-28 rounded-full bg-gradient-to-tr ${isOptimizing ? 'from-emerald-950 to-slate-800' : 'from-emerald-500/20 to-emerald-500/5'} border border-emerald-400/30 flex flex-col items-center justify-center text-center cursor-pointer shadow-lg shadow-emerald-500/5`}
              >
                <RefreshCw size={24} className={`text-emerald-400 mb-1 ${isOptimizing ? 'animate-spin' : ''}`} />
                <span className="text-xs font-bold text-emerald-300">
                  {isOptimizing ? `${optimizationProgress}%` : 'TỐI ƯU NGAY'}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {isOptimizing ? 'Đang chạy...' : 'Fix Lag Roblox'}
                </span>
              </motion.button>
            </div>

            <AnimatePresence mode="wait">
              {isOptimizing && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mt-6 text-center"
                >
                  <p className="text-xs font-medium text-emerald-300 font-mono">{currentStepText}</p>
                  <div className="w-56 h-1.5 bg-slate-800 rounded-full mx-auto mt-2 overflow-hidden">
                    <motion.div
                      className="h-full bg-emerald-400"
                      initial={{ width: 0 }}
                      animate={{ width: `${optimizationProgress}%` }}
                      transition={{ duration: 0.1 }}
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {!isOptimizing && (
              <div className="mt-6 flex gap-4 text-center">
                <div className="px-3 py-1 bg-slate-950/40 border border-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-500 block">GIẢM LAG</span>
                  <span className="text-xs font-bold text-emerald-400 font-mono">-45% Ping</span>
                </div>
                <div className="px-3 py-1 bg-slate-950/40 border border-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-500 block">TỐI ƯU RAM</span>
                  <span className="text-xs font-bold text-cyan-400 font-mono">+2.4 GB Trống</span>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Feature list overview */}
      <motion.div
        id="feature-overview"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-950/40 border border-slate-800 p-5 rounded-2xl"
      >
        <h3 className="text-sm font-bold text-slate-200 mb-3">Tính Năng Nổi Bật của Hack Kazu Client</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3 bg-slate-900/40 border border-slate-800/40 rounded-xl space-y-1">
            <span className="font-bold text-emerald-400">Siêu Tối Ưu Lag (Fix Lag)</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Giải phóng bộ nhớ đồ họa, hạ thấp cấu hình đổ bóng không cần thiết giúp game Roblox mượt tối đa 60-120 FPS kể cả máy yếu.
            </p>
          </div>
          <div className="p-3 bg-slate-900/40 border border-slate-800/40 rounded-xl space-y-1">
            <span className="font-bold text-cyan-400">Tương Thích Mọi Phiên Bản</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Hỗ trợ tối ưu hoàn hảo cho Delta Executor trên Roblox VNG hệ điều hành Android và iOS (gồm bản trực tiếp & IPA).
            </p>
          </div>
          <div className="p-3 bg-slate-900/40 border border-slate-800/40 rounded-xl space-y-1">
            <span className="font-bold text-purple-400">Chạy Script Độc Quyền</span>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              Hỗ trợ sao chép các bộ mã lệnh (Script) hack game hot nhất như Blox Fruits Kaitun, Auto Farm Chest, Tìm Trái Ác Quỷ hoàn toàn miễn phí.
            </p>
          </div>
        </div>
      </motion.div>

      {/* Beautiful step-by-step Installation Guide */}
      <motion.div
        id="installation-guide"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 md:p-6 relative overflow-hidden backdrop-blur-md"
      >
        <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-cyan-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/60">
          <div className="space-y-1">
            <h3 className="text-sm font-extrabold text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <HelpCircle className="text-cyan-400" size={18} />
              CỔNG HƯỚNG DẪN CÀI ĐẶT CHI TIẾT
            </h3>
            <p className="text-[11px] text-slate-400">Chọn hệ điều hành thiết bị của bạn để xem quy trình kích hoạt game chuẩn nhất</p>
          </div>

          {/* OS Switcher Buttons */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
            <button
              onClick={() => setSelectedOS('ios')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedOS === 'ios'
                  ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20 shadow-md shadow-rose-500/5 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone size={14} className="text-rose-400" />
              THIẾT BỊ iOS
            </button>
            <button
              onClick={() => setSelectedOS('android')}
              className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                selectedOS === 'android'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-md shadow-emerald-500/5 font-black'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone size={14} className="text-emerald-400" />
              THIẾT BỊ ANDROID (ADR)
            </button>
          </div>
        </div>

        {/* Dynamic platform guidelines */}
        <AnimatePresence mode="wait">
          {selectedOS === 'ios' ? (
            <motion.div
              key="ios-guide"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.15 }}
              className="mt-6 space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
                {/* Step 1 */}
                <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl relative flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold text-xs flex items-center justify-center font-mono">
                        01
                      </span>
                      <Download size={14} className="text-rose-400/70" />
                    </div>
                    <span className="text-xs font-bold text-slate-200 block uppercase">Tải File Cài Đặt (.IPA)</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Lấy đường liên kết tải xuống an toàn của tệp tin cài đặt Hack Kazu Client (.ipa) dành riêng cho hệ điều hành iOS.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="bg-slate-950/40 border border-rose-500/20 p-4 rounded-xl relative flex flex-col justify-between space-y-3 shadow-lg shadow-rose-500/5">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-rose-500/20 border border-rose-500 text-rose-400 font-extrabold text-xs flex items-center justify-center font-mono">
                        02
                      </span>
                      <Settings size={14} className="text-rose-400" />
                    </div>
                    <span className="text-xs font-black text-rose-300 block uppercase flex items-center gap-1">
                      Tin Cậy Thiết Bị 🔑
                    </span>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Nếu hệ thống yêu cầu cài đặt, hãy mở cài đặt điện thoại: Vào <strong className="text-rose-400">Cài đặt</strong> → <strong className="text-rose-400">Cài đặt chung</strong> → <strong className="text-rose-400">Quản lý VPN & Thiết bị</strong> → chọn nhà phát triển tin cậy để kích hoạt chứng chỉ.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl relative flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-400 font-bold text-xs flex items-center justify-center font-mono">
                        03
                      </span>
                      <RefreshCw size={14} className="text-rose-400/70" />
                    </div>
                    <span className="text-xs font-bold text-slate-200 block uppercase">Khởi Động Lại Máy 🔄</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Tiến hành tắt nguồn và khởi động lại toàn bộ thiết bị iOS của bạn để hệ thống cập nhật cấu hình bảo mật đáng tin cậy.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-rose-500/5 border border-rose-500/10 p-3 rounded-xl flex items-center gap-2.5 text-[10px] text-rose-400/90 font-medium">
                <ShieldAlert size={14} className="shrink-0" />
                <span>Lưu ý quan trọng cho iOS: Các bước phân quyền VPN & Thiết bị tin cậy là bắt buộc để ứng dụng chạy không bị lỗi Crash.</span>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="android-guide"
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 10 }}
              transition={{ duration: 0.15 }}
              className="mt-6 space-y-6"
            >
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
                {/* Step 1 */}
                <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl relative flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
                        01
                      </span>
                      <Download size={14} className="text-emerald-400/70" />
                    </div>
                    <span className="text-xs font-bold text-slate-200 block uppercase">Tải Tệp Tin APK</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Nhấp nút tải file cài đặt để tiến hành tải tệp tin Hack Kazu Client định dạng (.APK) trực tiếp về điện thoại Android của bạn.
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="bg-slate-950/40 border border-slate-800/60 p-4 rounded-xl relative flex flex-col justify-between space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-bold text-xs flex items-center justify-center font-mono">
                        02
                      </span>
                      <RefreshCw size={14} className="text-emerald-400 animate-spin-slow" />
                    </div>
                    <span className="text-xs font-bold text-slate-200 block uppercase">Đợi Tải Hoàn Tất ⏳</span>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      Giữ trình duyệt mở và đợi một lát cho đến khi tệp tin cài đặt được tải xuống xong hoàn toàn 100% về bộ nhớ máy.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="bg-slate-950/40 border border-emerald-500/20 p-4 rounded-xl relative flex flex-col justify-between space-y-3 shadow-lg shadow-emerald-500/5">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-6 h-6 rounded-lg bg-emerald-500/20 border border-emerald-500 text-emerald-400 font-extrabold text-xs flex items-center justify-center font-mono">
                        03
                      </span>
                      <CheckCircle size={14} className="text-emerald-400" />
                    </div>
                    <span className="text-xs font-black text-emerald-300 block uppercase flex items-center gap-1">
                      Bấm Mở & Cài Đặt
                    </span>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      Khi hệ thống thông báo tải xong, hãy nhấp thẳng trực tiếp vào tệp đó để kích hoạt trình cài đặt mặc định trên điện thoại và tải game thành công.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-emerald-500/5 border border-emerald-500/10 p-3 rounded-xl flex items-center gap-2.5 text-[10px] text-emerald-400/90 font-medium">
                <Info size={14} className="shrink-0" />
                <span>Mẹo Android: Đảm bảo bạn đã bật tùy chọn "Cho phép cài đặt ứng dụng không rõ nguồn gốc" trong Cài đặt hệ thống.</span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}
