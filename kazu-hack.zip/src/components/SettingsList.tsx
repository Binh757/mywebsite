import { useState } from 'react';
import { motion } from 'motion/react';
import { Download, Phone, Mail, ExternalLink, ShieldCheck, UserCheck, HelpCircle, Heart, Smartphone, Copy, Check, ShieldAlert, Settings } from 'lucide-react';

interface SettingsListProps {
  triggerNotification: (msg: string, type: 'success' | 'info') => void;
  addLog: (msg: string, type: 'system' | 'success' | 'warning' | 'error') => void;
}

export default function SettingsList({ triggerNotification, addLog }: SettingsListProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const downloadLinks = [
    {
      title: 'Delta VNG IOS Siêu Fix Lag',
      url: 'https://link4m.org/go/IJNskb',
      desc: 'Bản tải trực tiếp (Direct Install) cài qua Safari siêu tối ưu, hạn chế văng game.',
      badge: 'iOS - Safari Fix Lag',
      color: 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/20 text-emerald-400',
      btnBg: 'bg-emerald-500 hover:bg-emerald-400 text-slate-950',
    },
    {
      title: 'IPA Delta VNG IOS',
      url: 'https://link4m.net/go/dNx0Gli9',
      desc: 'File định dạng IPA tải về máy để tự ký hoặc cài qua Scarlet, Esign, TrollStore.',
      badge: 'iOS - File IPA Sạch',
      color: 'from-cyan-500/20 to-cyan-500/5 border-cyan-500/20 text-cyan-400',
      btnBg: 'bg-cyan-500 hover:bg-cyan-400 text-slate-950',
    },
    {
      title: 'Delta VNG ADR Siêu Fix Lag',
      url: 'https://link4m.org/go/b39YJ',
      desc: 'File cài đặt APK mượt cho hệ điều hành Android, tự động chống lag và văng game.',
      badge: 'Android APK Fix Lag',
      color: 'from-purple-500/20 to-purple-500/5 border-purple-500/20 text-purple-400',
      btnBg: 'bg-purple-500 hover:bg-purple-400 text-slate-950',
    }
  ];

  const adminContacts = [
    {
      name: 'By ᴀᴅᴍ〆Kazu & ᴀᴅᴍ〆Kaizo',
      phone: '0947691156',
      email: 'leg027877@gmail.com',
      role: 'Chủ sở hữu & Đại lý Key VIP Hack Kazu',
      avatarLetters: 'KZ',
    }
  ];

  const handleCopyText = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    triggerNotification(`Đã sao chép ${type}!`, 'success');
    addLog(`Đã sao chép thông tin ${type}: ${text}`, 'success');
    setTimeout(() => setCopiedText(null), 2000);
  };

  const handleOpenLink = (url: string, title: string) => {
    addLog(`Đang chuyển hướng: ${title}...`, 'system');
    window.open(url, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Download Section */}
      <div className="space-y-4">
        <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <Download className="text-emerald-400" size={16} />
          Đường Dẫn Tải Delta VNG Mới Nhất
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {downloadLinks.map((link, idx) => (
            <motion.div
              key={idx}
              id={`download-card-${idx}`}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className={`p-5 rounded-2xl border bg-gradient-to-br ${link.color} flex flex-col justify-between h-full space-y-4 relative overflow-hidden`}
            >
              <div className="space-y-2 relative z-10">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-950/60 border border-slate-800 font-bold uppercase tracking-wider">
                    {link.badge}
                  </span>
                  <Smartphone size={14} className="opacity-60" />
                </div>
                
                <h3 className="text-sm font-extrabold text-slate-100 tracking-tight leading-snug">
                  {link.title}
                </h3>
                
                <p className="text-[11px] text-slate-400 leading-relaxed font-sans">
                  {link.desc}
                </p>
              </div>

              <div className="pt-2 relative z-10">
                <button
                  onClick={() => handleOpenLink(link.url, link.title)}
                  className={`w-full py-2.5 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-sm transition-all transform hover:-translate-y-0.5 ${link.btnBg}`}
                >
                  <span>TẢI TRỰC TIẾP</span>
                  <ExternalLink size={12} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* NEW: DNS Anti-Block iOS Section */}
      <motion.div
        id="dns-bypass-ios-section"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.15 }}
        className="bg-slate-900/60 border border-amber-500/20 rounded-2xl p-6 relative overflow-hidden backdrop-blur-md"
      >
        <div className="absolute top-0 right-0 w-40 h-40 bg-amber-500/5 rounded-full blur-3xl -z-10 pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[10px] font-bold rounded-md uppercase tracking-wider font-mono">
                KHUYÊN DÙNG CHO IPHONE
              </span>
              <span className="px-2.5 py-0.5 bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-bold rounded-md uppercase tracking-wider font-mono">
                ANTI-BLOCK DNS
              </span>
            </div>

            <h3 className="text-base font-extrabold text-slate-100 flex items-center gap-2 tracking-tight">
              <ShieldAlert className="text-amber-400 animate-pulse" size={20} />
              Cấu Hình DNS Tránh Chặn Trên iPhone (iOS)
            </h3>

            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Giải pháp tối ưu giúp khắc phục lỗi nhà mạng Việt Nam (Viettel, FPT, VNPT) chặn không cho tải trực tiếp ứng dụng Delta VNG qua Safari, lỗi không tải được cấu hình chứng chỉ, hoặc lỗi mất kết nối không vào được game Roblox.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] text-amber-400 font-bold block font-mono">BƯỚC 1</span>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Bấm nút tải cấu hình DNS phía bên phải về thiết bị iPhone của bạn.
                </p>
              </div>
              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] text-amber-400 font-bold block font-mono">BƯỚC 2</span>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Vào <strong className="text-slate-200">Cài đặt chung</strong> &gt; <strong className="text-slate-200">Quản lý VPN & Thiết bị</strong>, chọn cấu hình vừa tải.
                </p>
              </div>
              <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1">
                <span className="text-[10px] text-amber-400 font-bold block font-mono">BƯỚC 3</span>
                <p className="text-[11px] text-slate-400 leading-normal">
                  Bấm <strong className="text-amber-400">Cài đặt (Install)</strong> và xác nhận tin cậy để hoàn tất chống chặn.
                </p>
              </div>
            </div>
          </div>

          <div className="md:w-64 shrink-0 flex flex-col justify-center">
            <button
              onClick={() => handleOpenLink('https://link4m.net/go/trYByP', 'DNS tránh chặn trên iPhone')}
              className="w-full py-3.5 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs tracking-wider rounded-xl shadow-lg shadow-amber-500/10 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2 cursor-pointer uppercase"
            >
              <span>CÀI ĐẶT DNS TRÁNH CHẶN</span>
              <ExternalLink size={14} />
            </button>
            <span className="text-[10px] text-center text-slate-500 mt-2 block font-mono">
              Liên kết sạch &bull; Đã kiểm duyệt an toàn
            </span>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Admin Contact Panel */}
        <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-2xl space-y-5">
          <div className="space-y-1">
            <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <UserCheck className="text-emerald-400" size={16} />
              Thông Tin Mua Key & Hỗ Trợ Kỹ Thuật
            </h2>
            <p className="text-[11px] text-slate-400">
              Liên hệ admin chính thức của Hack Kazu để kích hoạt Key VIP không giới hạn quảng cáo.
            </p>
          </div>

          <div className="space-y-4">
            {adminContacts.map((contact, i) => (
              <div key={i} className="bg-slate-950/60 border border-slate-800/80 p-4 rounded-xl flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-cyan-500/20 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-base select-none shrink-0 font-mono">
                  {contact.avatarLetters}
                </div>
                
                <div className="space-y-2 flex-1 min-w-0">
                  <div>
                    <h3 className="text-xs font-extrabold text-slate-100 uppercase tracking-wider font-mono">
                      {contact.name}
                    </h3>
                    <span className="text-[10px] text-emerald-400 font-medium block">
                      {contact.role}
                    </span>
                  </div>

                  <div className="space-y-1 text-xs">
                    {/* Phone Row */}
                    <div className="flex items-center justify-between py-1 border-b border-slate-900">
                      <span className="text-slate-500 flex items-center gap-1.5 text-[11px]">
                        <Phone size={12} />
                        Số điện thoại:
                      </span>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-300 font-semibold">{contact.phone}</span>
                        <button
                          onClick={() => handleCopyText(contact.phone, 'Số điện thoại')}
                          className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                        >
                          {copiedText === contact.phone ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </div>

                    {/* Email Row */}
                    <div className="flex items-center justify-between py-1">
                      <span className="text-slate-500 flex items-center gap-1.5 text-[11px]">
                        <Mail size={12} />
                        Gmail:
                      </span>
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-mono text-slate-300 font-semibold truncate max-w-[150px] md:max-w-[200px]">
                          {contact.email}
                        </span>
                        <button
                          onClick={() => handleCopyText(contact.email, 'Gmail')}
                          className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-emerald-400 transition-colors cursor-pointer"
                        >
                          {copiedText === contact.email ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-emerald-500/5 border border-emerald-500/10 p-3 rounded-lg flex items-center gap-2.5">
            <ShieldCheck size={14} className="text-emerald-400 shrink-0" />
            <span className="text-[10px] text-slate-400 leading-relaxed">
              Mọi hoạt động chuyển khoản và thanh toán chỉ áp dụng cho số điện thoại và gmail của <strong className="text-slate-200">By ᴀᴅᴍ〆Kazu & ᴀᴅᴍ〆Kaizo</strong> được đề cập bên trên. Hãy cảnh giác với các trang mạo danh khác.
            </span>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="bg-slate-900/60 border border-slate-800 p-6 rounded-2xl space-y-4">
          <h2 className="text-sm font-bold text-slate-100 flex items-center gap-2">
            <HelpCircle className="text-cyan-400" size={16} />
            Hỏi Đáp & Trợ Giúp Về Cài Đặt
          </h2>

          <div className="space-y-3">
            {[
              {
                q: 'Lỗi Delta iOS hiển thị "Ứng dụng chưa được xác minh"?',
                a: 'Vào Cấu hình thiết bị -> Cài đặt chung -> Quản lý cấu hình & VPN -> Nhấn Tin cậy cấu hình chứng chỉ doanh nghiệp vừa cài để khởi động game.'
              },
              {
                q: 'Làm thế nào để cài đặt cấu hình DNS tránh chặn?',
                a: 'Bấm vào nút Cài đặt DNS tránh chặn ở khung phía trên, trình duyệt sẽ tải tệp .mobileconfig về máy. Cho phép tải xuống rồi tiến hành duyệt cấu hình trong Cài đặt iPhone.'
              },
              {
                q: 'Bản siêu Fix Lag có an toàn và không bị Ban acc không?',
                a: 'Hoàn toàn an toàn. Phiên bản được loại bỏ các tác vụ thừa của game, không can thiệp bất hợp pháp vào Roblox Core nên tỉ lệ an toàn 100%.'
              },
              {
                q: 'Có cách nào gia hạn Bypass Key tự động vĩnh viễn không?',
                a: 'Bạn có thể mua gói Key VIP trực tiếp từ đại lý By ᴀᴅᴍ〆Kazu & ᴀᴅᴍ〆Kaizo qua Số điện thoại hoặc Gmail phía bên trái để mở khóa trọn đời.'
              }
            ].map((faq, idx) => (
              <div key={idx} className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl space-y-1">
                <span className="text-xs font-bold text-slate-200 block">{faq.q}</span>
                <p className="text-[11px] text-slate-400 leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-1.5 text-[10px] text-slate-500 py-2">
        <Heart size={10} className="text-rose-500 animate-pulse" />
        <span>Bản quyền Hack Kazu Client phát triển cho game thủ Delta VNG Roblox.</span>
      </div>
    </div>
  );
}
