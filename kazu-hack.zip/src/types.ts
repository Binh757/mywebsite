export interface TerminalLog {
  id: string;
  timestamp: string;
  type: 'system' | 'success' | 'warning' | 'error' | 'script';
  message: string;
}

export interface SystemMetrics {
  ping: number;
  fps: number;
  ramUsage: number;
  bypassRate: number;
  activeUsers: number;
}
